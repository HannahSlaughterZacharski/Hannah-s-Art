This zip file contains a Big Red Consulting Excel Add-In.  


Follow the install steps carefully for best results.


First, copy all the files in the ZIP file to a single folder.  For Windows, we recommend a folder under your My Documents folder.  For Mac, a folder in your Documents folder.


After copying all the files, load the XLA file (the Excel Add-in) from within Excel. DO NOT attempt to load the XLA Add-in file by double-clicking it.  
Excel will attempt to launch it instead of installing it.  Instead, right-click it to save it to your hard disk, then:
� Launch Excel, then choose Tools | Add-ins | Browse.
� Press Select when using Mac Excel.
� Then browse to the XLA file, select it, and press OK.  

After install:
When you Install the Add-in, a custom menu is added to Excel, usually just to the right of Excel's Help menu. This is your primary interaction point with the Add-in.  

To use the Add-in, examine the options on this new menu. Look for an option to show the Documentation, the best place to start.

